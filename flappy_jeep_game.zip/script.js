
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const birdImg = new Image();
const bgImg = new Image();
const pipeImg = new Image();
birdImg.src = "images/bird.png";
bgImg.src = "images/background.png";
pipeImg.src = "images/pipe.png";

let bird = { x: 50, y: 150, width: 40, height: 40, gravity: 0.6, lift: -10, velocity: 0 };
let pipes = [];
let score = 0;
let gameOver = false;

document.addEventListener("keydown", () => {
  if (!gameOver) bird.velocity = bird.lift;
});

function drawBird() {
  ctx.drawImage(birdImg, bird.x, bird.y, bird.width, bird.height);
}

function drawPipes() {
  for (let p of pipes) {
    ctx.drawImage(pipeImg, p.x, p.y, p.width, p.height);
    ctx.drawImage(pipeImg, p.x, p.y + p.height + p.gap, p.width, canvas.height - (p.y + p.height + p.gap));
  }
}

function drawScore() {
  ctx.fillStyle = "#fff";
  ctx.font = "24px Arial";
  ctx.fillText("Score: " + score, 10, 30);
}

function update() {
  if (gameOver) return;

  ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

  bird.velocity += bird.gravity;
  bird.y += bird.velocity;

  if (bird.y + bird.height >= canvas.height) gameOver = true;

  if (frames % 90 === 0) {
    let pipeHeight = Math.floor(Math.random() * 200) + 100;
    pipes.push({ x: canvas.width, y: 0, width: 50, height: pipeHeight, gap: 140 });
  }

  pipes = pipes.map(p => {
    p.x -= 2;
    if (p.x + p.width < 0) {
      score++;
      return null;
    }

    if (
      bird.x < p.x + p.width &&
      bird.x + bird.width > p.x &&
      (bird.y < p.y + p.height || bird.y + bird.height > p.y + p.height + p.gap)
    ) {
      gameOver = true;
    }

    return p;
  }).filter(Boolean);

  drawPipes();
  drawBird();
  drawScore();

  if (!gameOver) requestAnimationFrame(update);
}

let frames = 0;
function gameLoop() {
  frames++;
  update();
  if (!gameOver) requestAnimationFrame(gameLoop);
}

gameLoop();
